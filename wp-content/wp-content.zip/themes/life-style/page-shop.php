<?php
/**
 * Created by PhpStorm.
 * User: narek
 * Date: 25.04.2017
 * Time: 22:55
 */

get_header(); ?>

    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">

            <img src="<?= get_template_directory_uri()?>/images/UnderConstruction.png" alt="">

        </main><!-- #main -->
    </div><!-- #primary -->

<?php
get_footer();
